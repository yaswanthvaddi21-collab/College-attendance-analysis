"""
Module: visualizer.py
Purpose: Generate all charts and graphs for attendance analysis
"""

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import numpy as np
import os

# ─────────────────────────────────────────────
# Global Style
# ─────────────────────────────────────────────
PALETTE   = ["#4361EE","#3A0CA3","#7209B7","#F72585","#4CC9F0","#4CAF50","#FF9800","#E91E63"]
BG_COLOR  = "#F8F9FA"
GRID_CLR  = "#DEE2E6"
TITLE_CLR = "#212529"
CHARTS    = "charts"

os.makedirs(CHARTS, exist_ok=True)

def _save(fig, name):
    path = os.path.join(CHARTS, name)
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)
    return path


# ─────────────────────────────────────────────
# 1. Department Attendance Bar Chart
# ─────────────────────────────────────────────

def plot_department_bar(dept_df):
    fig, ax = plt.subplots(figsize=(9, 5), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    bars = ax.barh(dept_df["department"], dept_df["avg_attendance_pct"],
                   color=PALETTE[:len(dept_df)], edgecolor="white", height=0.55)
    ax.axvline(75, color="#E63946", linewidth=2, linestyle="--", label="75% Threshold")
    for bar, val in zip(bars, dept_df["avg_attendance_pct"]):
        ax.text(val + 0.5, bar.get_y() + bar.get_height()/2,
                f"{val:.1f}%", va="center", fontsize=11, fontweight="bold", color=TITLE_CLR)
    ax.set_xlabel("Average Attendance (%)", fontsize=12)
    ax.set_title("Department-wise Average Attendance", fontsize=14, fontweight="bold", color=TITLE_CLR, pad=15)
    ax.set_xlim(0, 105)
    ax.legend(fontsize=10)
    ax.grid(axis="x", color=GRID_CLR, linewidth=0.8)
    ax.spines[["top","right","bottom"]].set_visible(False)
    fig.tight_layout()
    return _save(fig, "01_department_bar.png")


# ─────────────────────────────────────────────
# 2. Attendance Status Distribution Pie
# ─────────────────────────────────────────────

def plot_status_pie(student_summary_df):
    counts = student_summary_df["status"].value_counts()
    colors = {"Critical":"#E63946","Low":"#FF6B35","Moderate":"#FFB703","Good":"#57CC99","Excellent":"#4361EE"}
    clrs   = [colors.get(s, "#888") for s in counts.index]

    fig, ax = plt.subplots(figsize=(7, 7), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    wedges, texts, autotexts = ax.pie(
        counts, labels=counts.index, autopct="%1.1f%%",
        colors=clrs, startangle=140, pctdistance=0.75,
        wedgeprops={"edgecolor":"white","linewidth":2})
    for t in autotexts: t.set_fontsize(10); t.set_fontweight("bold")
    ax.set_title("Student Attendance Status Distribution", fontsize=14, fontweight="bold",
                 color=TITLE_CLR, pad=20)
    fig.tight_layout()
    return _save(fig, "02_status_pie.png")


# ─────────────────────────────────────────────
# 3. Monthly Trend Line Chart
# ─────────────────────────────────────────────

def plot_monthly_trend(monthly_df):
    month_names = {1:"Jan",2:"Feb",3:"Mar",4:"Apr",5:"May",6:"Jun",
                   7:"Jul",8:"Aug",9:"Sep",10:"Oct",11:"Nov",12:"Dec"}
    monthly_df = monthly_df.copy()
    monthly_df["month_name"] = monthly_df["month"].map(month_names)

    fig, ax = plt.subplots(figsize=(10, 5), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    ax.plot(monthly_df["month_name"], monthly_df["attendance_pct"],
            marker="o", linewidth=2.5, markersize=8, color=PALETTE[0], label="Attendance %")
    ax.fill_between(monthly_df["month_name"], monthly_df["attendance_pct"],
                    alpha=0.15, color=PALETTE[0])
    ax.axhline(75, color="#E63946", linestyle="--", linewidth=1.5, label="75% Threshold")
    for x, y in zip(monthly_df["month_name"], monthly_df["attendance_pct"]):
        ax.annotate(f"{y:.1f}%", (x, y), textcoords="offset points",
                    xytext=(0, 10), ha="center", fontsize=9, color=PALETTE[0])
    ax.set_xlabel("Month", fontsize=12)
    ax.set_ylabel("Attendance (%)", fontsize=12)
    ax.set_title("Monthly Attendance Trend", fontsize=14, fontweight="bold", color=TITLE_CLR)
    ax.set_ylim(60, 105)
    ax.legend(fontsize=10)
    ax.grid(color=GRID_CLR, linewidth=0.8)
    ax.spines[["top","right"]].set_visible(False)
    fig.tight_layout()
    return _save(fig, "03_monthly_trend.png")


# ─────────────────────────────────────────────
# 4. Day-wise Attendance Bar
# ─────────────────────────────────────────────

def plot_daywise(daywise_df):
    fig, ax = plt.subplots(figsize=(9, 5), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    colors = [PALETTE[i % len(PALETTE)] for i in range(len(daywise_df))]
    bars = ax.bar(daywise_df["day_name"], daywise_df["attendance_pct"],
                  color=colors, edgecolor="white", width=0.6)
    ax.axhline(75, color="#E63946", linewidth=2, linestyle="--", label="75% Threshold")
    for bar, val in zip(bars, daywise_df["attendance_pct"]):
        ax.text(bar.get_x() + bar.get_width()/2, val + 0.5,
                f"{val:.1f}%", ha="center", fontsize=11, fontweight="bold", color=TITLE_CLR)
    ax.set_xlabel("Day of Week", fontsize=12)
    ax.set_ylabel("Attendance (%)", fontsize=12)
    ax.set_title("Day-wise Attendance Pattern", fontsize=14, fontweight="bold", color=TITLE_CLR)
    ax.set_ylim(60, 105)
    ax.legend(fontsize=10)
    ax.grid(axis="y", color=GRID_CLR, linewidth=0.8)
    ax.spines[["top","right"]].set_visible(False)
    fig.tight_layout()
    return _save(fig, "04_daywise_bar.png")


# ─────────────────────────────────────────────
# 5. Subject Attendance Heatmap
# ─────────────────────────────────────────────

def plot_subject_heatmap(subject_df):
    pivot = subject_df.pivot(index="department", columns="subject", values="avg_attendance_pct")
    fig, ax = plt.subplots(figsize=(14, 6), facecolor=BG_COLOR)
    sns.heatmap(pivot, annot=True, fmt=".1f", cmap="YlGnBu",
                linewidths=0.5, linecolor="white",
                cbar_kws={"label":"Attendance %"}, ax=ax)
    ax.set_title("Subject-wise Attendance Heatmap (by Department)", fontsize=14,
                 fontweight="bold", color=TITLE_CLR, pad=15)
    ax.set_xlabel("Subject", fontsize=11)
    ax.set_ylabel("Department", fontsize=11)
    ax.tick_params(axis="x", rotation=45)
    fig.tight_layout()
    return _save(fig, "05_subject_heatmap.png")


# ─────────────────────────────────────────────
# 6. Histogram: Attendance Distribution
# ─────────────────────────────────────────────

def plot_attendance_histogram(student_summary_df):
    fig, ax = plt.subplots(figsize=(9, 5), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    ax.hist(student_summary_df["attendance_pct"], bins=20, color=PALETTE[0],
            edgecolor="white", alpha=0.9)
    ax.axvline(75, color="#E63946", linewidth=2, linestyle="--", label="75% Threshold")
    ax.axvline(student_summary_df["attendance_pct"].mean(), color="#2DC653",
               linewidth=2, linestyle="--",
               label=f"Mean: {student_summary_df['attendance_pct'].mean():.1f}%")
    ax.set_xlabel("Attendance Percentage", fontsize=12)
    ax.set_ylabel("Number of Students", fontsize=12)
    ax.set_title("Distribution of Student Attendance", fontsize=14, fontweight="bold", color=TITLE_CLR)
    ax.legend(fontsize=10)
    ax.grid(axis="y", color=GRID_CLR, linewidth=0.8)
    ax.spines[["top","right"]].set_visible(False)
    fig.tight_layout()
    return _save(fig, "06_attendance_histogram.png")


# ─────────────────────────────────────────────
# 7. Semester Comparison
# ─────────────────────────────────────────────

def plot_semester_comparison(sem_df):
    fig, ax = plt.subplots(figsize=(9, 5), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    bars = ax.bar([f"Sem {s}" for s in sem_df["semester"]], sem_df["attendance_pct"],
                  color=PALETTE[:len(sem_df)], edgecolor="white", width=0.6)
    ax.axhline(75, color="#E63946", linewidth=2, linestyle="--", label="75% Threshold")
    for bar, val in zip(bars, sem_df["attendance_pct"]):
        ax.text(bar.get_x() + bar.get_width()/2, val + 0.4,
                f"{val:.1f}%", ha="center", fontsize=10, fontweight="bold")
    ax.set_xlabel("Semester", fontsize=12)
    ax.set_ylabel("Avg Attendance (%)", fontsize=12)
    ax.set_title("Semester-wise Attendance Comparison", fontsize=14, fontweight="bold", color=TITLE_CLR)
    ax.set_ylim(60, 105)
    ax.legend(fontsize=10)
    ax.grid(axis="y", color=GRID_CLR, linewidth=0.8)
    ax.spines[["top","right"]].set_visible(False)
    fig.tight_layout()
    return _save(fig, "07_semester_comparison.png")


# ─────────────────────────────────────────────
# 8. Top 10 Defaulters Bar
# ─────────────────────────────────────────────

def plot_defaulters(below_df, top_n=10):
    df = below_df.nsmallest(top_n, "attendance_pct")
    fig, ax = plt.subplots(figsize=(10, 6), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    colors = ["#E63946" if v < 60 else "#FF6B35" if v < 70 else "#FFB703"
              for v in df["attendance_pct"]]
    bars = ax.barh(df["name"] + " (" + df["department"] + ")",
                   df["attendance_pct"], color=colors, edgecolor="white")
    ax.axvline(75, color="#4361EE", linewidth=2, linestyle="--", label="75% Threshold")
    for bar, val in zip(bars, df["attendance_pct"]):
        ax.text(val + 0.3, bar.get_y() + bar.get_height()/2,
                f"{val:.1f}%", va="center", fontsize=10, fontweight="bold")
    ax.set_xlabel("Attendance (%)", fontsize=12)
    ax.set_title(f"Top {top_n} Students Needing Attention (Lowest Attendance)",
                 fontsize=13, fontweight="bold", color=TITLE_CLR)
    ax.set_xlim(0, 90)
    ax.legend(fontsize=10)
    ax.grid(axis="x", color=GRID_CLR, linewidth=0.8)
    ax.spines[["top","right","bottom"]].set_visible(False)
    fig.tight_layout()
    return _save(fig, "08_defaulters_bar.png")


# ─────────────────────────────────────────────
# 9. Gender-wise Comparison
# ─────────────────────────────────────────────

def plot_gender(gender_df):
    fig, ax = plt.subplots(figsize=(6, 5), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    clrs = ["#4361EE","#F72585"]
    bars = ax.bar(gender_df["gender"], gender_df["avg_attendance_pct"],
                  color=clrs, edgecolor="white", width=0.45)
    ax.axhline(75, color="#E63946", linewidth=2, linestyle="--", label="75% Threshold")
    for bar, val in zip(bars, gender_df["avg_attendance_pct"]):
        ax.text(bar.get_x() + bar.get_width()/2, val + 0.4,
                f"{val:.2f}%", ha="center", fontsize=13, fontweight="bold")
    ax.set_ylabel("Avg Attendance (%)", fontsize=12)
    ax.set_title("Gender-wise Attendance Comparison", fontsize=14, fontweight="bold", color=TITLE_CLR)
    ax.set_ylim(60, 105)
    ax.legend(fontsize=10)
    ax.grid(axis="y", color=GRID_CLR, linewidth=0.8)
    ax.spines[["top","right"]].set_visible(False)
    fig.tight_layout()
    return _save(fig, "09_gender_comparison.png")


# ─────────────────────────────────────────────
# 10. Scatter: Classes vs Attendance %
# ─────────────────────────────────────────────

def plot_scatter_classes_vs_pct(student_summary_df):
    df = student_summary_df.copy()
    color_map = {"Critical":"#E63946","Low":"#FF6B35","Moderate":"#FFB703",
                 "Good":"#57CC99","Excellent":"#4361EE"}
    df["color"] = df["status"].map(color_map)
    fig, ax = plt.subplots(figsize=(10, 6), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    for status, grp in df.groupby("status"):
        ax.scatter(grp["total_classes"], grp["attendance_pct"],
                   c=color_map.get(str(status), "#888"), label=str(status),
                   alpha=0.7, s=50, edgecolors="white", linewidth=0.5)
    ax.axhline(75, color="#E63946", linewidth=1.5, linestyle="--", label="75% Line")
    ax.set_xlabel("Total Classes Held", fontsize=12)
    ax.set_ylabel("Attendance %", fontsize=12)
    ax.set_title("Total Classes vs Attendance % (per Student)", fontsize=14,
                 fontweight="bold", color=TITLE_CLR)
    ax.legend(fontsize=10)
    ax.grid(color=GRID_CLR, linewidth=0.8)
    ax.spines[["top","right"]].set_visible(False)
    fig.tight_layout()
    return _save(fig, "10_scatter_classes_vs_pct.png")
