"""
Module: data_generator.py
Purpose: Generate realistic sample attendance data for demonstration
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
import os

# ─────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────
DEPARTMENTS = ["CSE", "ECE", "MECH", "CIVIL", "EEE"]
SUBJECTS = {
    "CSE": ["Python Programming", "Data Structures", "DBMS", "OS", "Computer Networks", "AI & ML"],
    "ECE": ["Digital Electronics", "Signals & Systems", "VLSI Design", "Microprocessors", "Communication Systems"],
    "MECH": ["Thermodynamics", "Fluid Mechanics", "Machine Design", "Manufacturing", "Heat Transfer"],
    "CIVIL": ["Structural Analysis", "Soil Mechanics", "Surveying", "RCC Design", "Environmental Engg"],
    "EEE":  ["Electrical Machines", "Power Systems", "Control Systems", "Power Electronics", "Drives"],
}
FACULTY = {
    "CSE": ["Dr. Ravi Kumar", "Prof. Anitha Reddy", "Dr. Suresh Babu"],
    "ECE": ["Dr. Priya Sharma", "Prof. Mohan Das", "Dr. Lakshmi Nair"],
    "MECH": ["Dr. Ramesh Rao", "Prof. Vijay Singh", "Dr. Ajay Mehta"],
    "CIVIL": ["Dr. Neha Gupta", "Prof. Arun Verma", "Dr. Sneha Patil"],
    "EEE":  ["Dr. Kiran Babu", "Prof. Sita Devi", "Dr. Manoj Kumar"],
}

SEMESTERS = [1, 2, 3, 4, 5, 6, 7, 8]

def generate_students(n_per_dept=30):
    """Generate student records across departments."""
    first_names = ["Arjun","Priya","Rahul","Sneha","Amit","Divya","Rohit","Kavya","Suresh","Nisha",
                   "Kiran","Meena","Raj","Pooja","Anil","Ritu","Vijay","Sonal","Deepak","Ananya",
                   "Harish","Swathi","Naveen","Rekha","Sanjay","Lakshmi","Prasad","Uma","Ganesh","Saritha"]
    last_names  = ["Kumar","Reddy","Sharma","Rao","Naidu","Gupta","Singh","Verma","Patil","Nair",
                   "Das","Mehta","Joshi","Shah","Pillai","Iyer","Menon","Bose","Patel","Chauhan"]

    students = []
    roll_counter = {dept: 1 for dept in DEPARTMENTS}
    for dept in DEPARTMENTS:
        for i in range(n_per_dept):
            sem = random.choice(SEMESTERS)
            year = (sem + 1) // 2
            roll = f"{dept[:2]}{2020+year-1}{roll_counter[dept]:03d}"
            roll_counter[dept] += 1
            students.append({
                "roll_no":    roll,
                "name":       f"{random.choice(first_names)} {random.choice(last_names)}",
                "department": dept,
                "semester":   sem,
                "year":       year,
                "email":      f"{roll.lower()}@college.edu",
                "phone":      f"9{random.randint(100000000,999999999)}",
                "gender":     random.choice(["Male","Female"]),
            })
    return pd.DataFrame(students)

def generate_attendance(students_df, start_date="2024-01-01", end_date="2024-04-30"):
    """Generate attendance records with realistic patterns."""
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end   = datetime.strptime(end_date,   "%Y-%m-%d")
    working_days = [start + timedelta(days=d)
                    for d in range((end - start).days + 1)
                    if (start + timedelta(days=d)).weekday() < 5]

    records = []
    for _, student in students_df.iterrows():
        dept    = student["department"]
        subjects = SUBJECTS[dept]
        # Base attendance probability per student (some students are habitual absentees)
        base_prob = random.uniform(0.60, 0.98)

        for date in working_days:
            for subject in subjects:
                faculty = random.choice(FACULTY[dept])
                # Slight variation per subject
                prob = base_prob * random.uniform(0.85, 1.15)
                prob = max(0.3, min(1.0, prob))
                status = "Present" if random.random() < prob else "Absent"
                records.append({
                    "date":       date.strftime("%Y-%m-%d"),
                    "roll_no":    student["roll_no"],
                    "name":       student["name"],
                    "department": dept,
                    "semester":   student["semester"],
                    "subject":    subject,
                    "faculty":    faculty,
                    "status":     status,
                    "period":     random.randint(1, 6),
                })

    return pd.DataFrame(records)

def save_data(students_df, attendance_df, path="data"):
    os.makedirs(path, exist_ok=True)
    students_df.to_csv(f"{path}/students.csv", index=False)
    attendance_df.to_csv(f"{path}/attendance.csv", index=False)
    print(f"[✔] Saved {len(students_df)} students and {len(attendance_df)} attendance records.")
