"""
Module: report_generator.py
Purpose: Generate PDF and Excel reports from analysis results
"""

import os
import pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,
                                 Spacer, Image, PageBreak, HRFlowable)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

os.makedirs("reports", exist_ok=True)

# ─────────────────────────────────────────────
# Colour Palette
# ─────────────────────────────────────────────
BLUE     = colors.HexColor("#4361EE")
DARK     = colors.HexColor("#212529")
LIGHT_BG = colors.HexColor("#F0F4FF")
RED_ACC  = colors.HexColor("#E63946")
GREEN    = colors.HexColor("#2DC653")
ORANGE   = colors.HexColor("#FF6B35")
GREY     = colors.HexColor("#ADB5BD")


def _styles():
    s = getSampleStyleSheet()
    s.add(ParagraphStyle("Title2", parent=s["Title"], fontSize=22, textColor=BLUE,
                          spaceAfter=6, alignment=TA_CENTER))
    s.add(ParagraphStyle("SubTitle", parent=s["Normal"], fontSize=12, textColor=GREY,
                          spaceAfter=4, alignment=TA_CENTER))
    s.add(ParagraphStyle("SectionHead", parent=s["Heading2"], fontSize=13, textColor=BLUE,
                          spaceBefore=14, spaceAfter=6, borderPadding=(0,0,2,0)))
    s.add(ParagraphStyle("Body2", parent=s["Normal"], fontSize=10, textColor=DARK,
                          spaceAfter=4, leading=14))
    s.add(ParagraphStyle("TableHeader", parent=s["Normal"], fontSize=10,
                          textColor=colors.white, fontName="Helvetica-Bold", alignment=TA_CENTER))
    s.add(ParagraphStyle("Cell", parent=s["Normal"], fontSize=9, textColor=DARK,
                          alignment=TA_CENTER))
    return s


def _table_style(header_color=BLUE):
    return TableStyle([
        ("BACKGROUND",   (0, 0), (-1, 0), header_color),
        ("TEXTCOLOR",    (0, 0), (-1, 0), colors.white),
        ("FONTNAME",     (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",     (0, 0), (-1, 0), 10),
        ("ALIGN",        (0, 0), (-1, -1), "CENTER"),
        ("VALIGN",       (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS",(0, 1), (-1, -1), [colors.white, LIGHT_BG]),
        ("GRID",         (0, 0), (-1, -1), 0.5, GREY),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 6),
        ("TOPPADDING",   (0, 0), (-1, -1), 6),
        ("FONTSIZE",     (0, 1), (-1, -1), 9),
    ])


def generate_pdf_report(stats, dept_df, subject_df, below_df,
                         monthly_df, sem_df, gender_df, chart_paths,
                         output="reports/Attendance_Analysis_Report.pdf"):

    doc   = SimpleDocTemplate(output, pagesize=A4,
                               leftMargin=1.5*cm, rightMargin=1.5*cm,
                               topMargin=2*cm, bottomMargin=2*cm)
    S     = _styles()
    story = []

    # ── Cover Page ──────────────────────────────────
    story.append(Spacer(1, 1.5*inch))
    story.append(Paragraph("🎓 College Attendance Analysis", S["Title2"]))
    story.append(Paragraph("BSc Computer Science — Group Project Report", S["SubTitle"]))
    story.append(Spacer(1, 0.2*inch))
    story.append(HRFlowable(width="100%", thickness=2, color=BLUE))
    story.append(Spacer(1, 0.15*inch))

    meta = [
        ["Academic Year", "2024-25"],
        ["Semester",      "Even Semester (Jan – Apr 2024)"],
        ["Project Type",  "Group Project — Data Analysis"],
        ["Language",      "Python (pandas, matplotlib, seaborn, reportlab)"],
        ["Report Date",   pd.Timestamp.today().strftime("%d %B %Y")],
    ]
    t = Table(meta, colWidths=[2.5*inch, 4*inch])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (0,-1), LIGHT_BG),
        ("FONTNAME",   (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTSIZE",   (0,0), (-1,-1), 10),
        ("GRID",       (0,0), (-1,-1), 0.5, GREY),
        ("ALIGN",      (0,0), (-1,-1), "LEFT"),
        ("BOTTOMPADDING",(0,0),(-1,-1), 7),
        ("TOPPADDING",   (0,0),(-1,-1), 7),
        ("LEFTPADDING",  (0,0),(-1,-1), 8),
    ]))
    story.append(t)
    story.append(PageBreak())

    # ── 1. Executive Summary ─────────────────────────
    story.append(Paragraph("1. Executive Summary", S["SectionHead"]))
    story.append(HRFlowable(width="100%", thickness=1, color=BLUE))
    story.append(Spacer(1, 0.1*inch))

    stat_rows = [[k, str(v)] for k, v in stats.items()]
    stat_rows.insert(0, ["Metric", "Value"])
    st = Table(stat_rows, colWidths=[3.5*inch, 3*inch])
    st.setStyle(_table_style())
    story.append(st)
    story.append(Spacer(1, 0.15*inch))
    story.append(Paragraph(
        f"The overall average attendance across all departments is "
        f"<b>{stats.get('Overall Avg Attendance %', 'N/A')}%</b>. "
        f"A total of <b>{stats.get('Students Below 75%', 'N/A')}</b> students are below "
        f"the minimum required 75% threshold and require immediate intervention.",
        S["Body2"]))

    # ── 2. Department Analysis ───────────────────────
    story.append(Paragraph("2. Department-wise Analysis", S["SectionHead"]))
    story.append(HRFlowable(width="100%", thickness=1, color=BLUE))
    story.append(Spacer(1, 0.1*inch))

    if "01_department_bar.png" in [os.path.basename(p) for p in chart_paths]:
        img_p = next(p for p in chart_paths if "01_department" in p)
        story.append(Image(img_p, width=6.5*inch, height=3.5*inch))
        story.append(Spacer(1, 0.1*inch))

    dept_rows = [["Department","Avg Attendance (%)"]] + dept_df.values.tolist()
    dt = Table(dept_rows, colWidths=[3*inch, 3*inch])
    dt.setStyle(_table_style())
    story.append(dt)

    # ── 3. Charts ────────────────────────────────────
    chart_sections = [
        ("3. Attendance Status Distribution",  "02_status_pie"),
        ("4. Monthly Attendance Trend",         "03_monthly_trend"),
        ("5. Day-wise Attendance Pattern",      "04_daywise_bar"),
        ("6. Subject-wise Attendance Heatmap",  "05_subject_heatmap"),
        ("7. Attendance Distribution Histogram","06_attendance_histogram"),
        ("8. Semester Comparison",              "07_semester_comparison"),
        ("9. Students Needing Attention",       "08_defaulters_bar"),
        ("10. Gender-wise Comparison",          "09_gender_comparison"),
        ("11. Classes vs Attendance Scatter",   "10_scatter_classes_vs_pct"),
    ]
    for sec_title, key in chart_sections:
        matches = [p for p in chart_paths if key in p]
        if matches:
            story.append(PageBreak())
            story.append(Paragraph(sec_title, S["SectionHead"]))
            story.append(HRFlowable(width="100%", thickness=1, color=BLUE))
            story.append(Spacer(1, 0.1*inch))
            w = 6.5*inch if "heatmap" in key else 5.8*inch
            h = 4*inch   if "heatmap" in key else 3.5*inch
            story.append(Image(matches[0], width=w, height=h))

    # ── 4. Students Below 75% ────────────────────────
    story.append(PageBreak())
    story.append(Paragraph("12. Students Below 75% Attendance (Needs Action)", S["SectionHead"]))
    story.append(HRFlowable(width="100%", thickness=1, color=RED_ACC))
    story.append(Spacer(1, 0.1*inch))

    cols     = ["roll_no","name","department","semester","attendance_pct","shortage"]
    headers  = ["Roll No","Name","Dept","Sem","Attendance %","Classes Short"]
    sub_df   = below_df[cols].head(25)
    rows     = [headers] + sub_df.values.tolist()
    bt = Table(rows, colWidths=[1*inch, 1.8*inch, 0.7*inch, 0.5*inch, 1.1*inch, 1.1*inch])
    bt.setStyle(_table_style(header_color=RED_ACC))
    story.append(bt)

    # ── 5. Recommendations ───────────────────────────
    story.append(PageBreak())
    story.append(Paragraph("13. Recommendations & Conclusions", S["SectionHead"]))
    story.append(HRFlowable(width="100%", thickness=1, color=BLUE))
    story.append(Spacer(1, 0.1*inch))
    recs = [
        "1. <b>Early Intervention:</b> Contact students who fall below 65% attendance within the first 4 weeks.",
        "2. <b>Subject-Level Audit:</b> Subjects with attendance below the college average should be reviewed for scheduling or engagement issues.",
        "3. <b>Monday Effect:</b> If Monday attendance is significantly lower, consider starting important lectures on Tuesday.",
        "4. <b>Automated Alerts:</b> Deploy an SMS/email alert system when a student's attendance drops below 80%.",
        "5. <b>Parent Notification:</b> Notify parents/guardians when a student crosses the 75% danger mark.",
        "6. <b>Incentive Programme:</b> Reward students with ≥95% attendance with preference in internship/placement recommendations.",
        "7. <b>Faculty Engagement:</b> Faculty whose classes consistently have low attendance should discuss engagement strategies with HOD.",
        "8. <b>Semester Trend:</b> Higher semester students often have lower attendance due to placements; additional flexibility may be warranted.",
    ]
    for rec in recs:
        story.append(Paragraph(rec, S["Body2"]))

    story.append(Spacer(1, 0.3*inch))
    story.append(HRFlowable(width="100%", thickness=1, color=GREY))
    story.append(Spacer(1, 0.1*inch))
    story.append(Paragraph("Report generated using Python | pandas • matplotlib • seaborn • reportlab",
                             ParagraphStyle("Footer", parent=S["Normal"], fontSize=8,
                                            textColor=GREY, alignment=TA_CENTER)))

    doc.build(story)
    print(f"[✔] PDF report saved → {output}")
    return output


def generate_excel_report(student_summary_df, dept_df, subject_df,
                           below_df, gender_df,
                           output="reports/Attendance_Data.xlsx"):
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        student_summary_df.to_excel(writer, sheet_name="All Students",     index=False)
        below_df.to_excel(         writer, sheet_name="Below 75%",         index=False)
        dept_df.to_excel(          writer, sheet_name="Dept Summary",       index=False)
        subject_df.to_excel(       writer, sheet_name="Subject Summary",    index=False)
        gender_df.to_excel(        writer, sheet_name="Gender Analysis",    index=False)
    print(f"[✔] Excel report saved → {output}")
    return output
