"""
Module: analysis.py
Purpose: Core attendance analysis functions
"""

import pandas as pd
import numpy as np


# ─────────────────────────────────────────────
# 1. Load & Preprocess
# ─────────────────────────────────────────────

def load_data(students_path="data/students.csv", attendance_path="data/attendance.csv"):
    students   = pd.read_csv(students_path)
    attendance = pd.read_csv(attendance_path, parse_dates=["date"])
    print(f"[✔] Loaded {len(students)} students | {len(attendance)} records")
    return students, attendance


def preprocess(attendance_df):
    df = attendance_df.copy()
    df["is_present"] = (df["status"] == "Present").astype(int)
    df["month"]      = df["date"].dt.month
    df["week"]       = df["date"].dt.isocalendar().week.astype(int)
    df["day_name"]   = df["date"].dt.day_name()
    return df


# ─────────────────────────────────────────────
# 2. Student-Level Analysis
# ─────────────────────────────────────────────

def student_attendance_summary(df):
    """Compute per-student attendance percentage."""
    summary = (df.groupby(["roll_no", "name", "department", "semester"])
                 .agg(total_classes=("is_present","count"),
                      present=("is_present","sum"))
                 .reset_index())
    summary["attendance_pct"] = (summary["present"] / summary["total_classes"] * 100).round(2)
    summary["status"] = pd.cut(summary["attendance_pct"],
                                bins=[0, 50, 60, 75, 85, 100],
                                labels=["Critical", "Low", "Moderate", "Good", "Excellent"],
                                include_lowest=True)
    return summary.sort_values("attendance_pct")


def students_below_threshold(summary_df, threshold=75):
    """Return students below attendance threshold (defaulting to 75%)."""
    below = summary_df[summary_df["attendance_pct"] < threshold].copy()
    below["shortage"] = (below["total_classes"] * threshold / 100 - below["present"]).apply(np.ceil).astype(int)
    return below


def classes_needed_to_reach(summary_df, target_pct=75):
    """Calculate how many consecutive classes a student must attend to reach target."""
    df = summary_df[summary_df["attendance_pct"] < target_pct].copy()
    # (present + x) / (total + x) = target  →  x = (target*total - present) / (1 - target)
    t = target_pct / 100
    df["classes_needed"] = ((t * df["total_classes"] - df["present"]) / (1 - t)).apply(np.ceil).astype(int)
    df["classes_needed"] = df["classes_needed"].clip(lower=0)
    return df[["roll_no","name","department","attendance_pct","classes_needed"]]


# ─────────────────────────────────────────────
# 3. Department-Level Analysis
# ─────────────────────────────────────────────

def department_summary(df):
    """Average attendance per department."""
    return (df.groupby("department")["is_present"]
              .mean()
              .mul(100)
              .round(2)
              .reset_index()
              .rename(columns={"is_present":"avg_attendance_pct"})
              .sort_values("avg_attendance_pct", ascending=False))


# ─────────────────────────────────────────────
# 4. Subject-Level Analysis
# ─────────────────────────────────────────────

def subject_summary(df):
    """Average attendance per subject."""
    return (df.groupby(["department","subject"])["is_present"]
              .mean()
              .mul(100)
              .round(2)
              .reset_index()
              .rename(columns={"is_present":"avg_attendance_pct"})
              .sort_values("avg_attendance_pct"))


# ─────────────────────────────────────────────
# 5. Trend Analysis
# ─────────────────────────────────────────────

def monthly_trend(df):
    """Attendance trend month-wise."""
    return (df.groupby("month")["is_present"]
              .mean()
              .mul(100)
              .round(2)
              .reset_index()
              .rename(columns={"is_present":"attendance_pct"}))


def weekly_trend(df):
    """Attendance trend week-wise."""
    return (df.groupby("week")["is_present"]
              .mean()
              .mul(100)
              .round(2)
              .reset_index()
              .rename(columns={"is_present":"attendance_pct"}))


def daywise_trend(df):
    """Attendance by day of week."""
    order = ["Monday","Tuesday","Wednesday","Thursday","Friday"]
    result = (df.groupby("day_name")["is_present"]
                .mean()
                .mul(100)
                .round(2)
                .reindex(order)
                .reset_index()
                .rename(columns={"is_present":"attendance_pct"}))
    return result


# ─────────────────────────────────────────────
# 6. Semester Comparison
# ─────────────────────────────────────────────

def semester_summary(df):
    return (df.groupby("semester")["is_present"]
              .mean()
              .mul(100)
              .round(2)
              .reset_index()
              .rename(columns={"is_present":"attendance_pct"})
              .sort_values("semester"))


# ─────────────────────────────────────────────
# 7. Faculty Analysis
# ─────────────────────────────────────────────

def faculty_summary(df):
    """Average attendance in classes taken by each faculty."""
    return (df.groupby(["faculty","department"])["is_present"]
              .mean()
              .mul(100)
              .round(2)
              .reset_index()
              .rename(columns={"is_present":"avg_attendance_pct"})
              .sort_values("avg_attendance_pct", ascending=False))


# ─────────────────────────────────────────────
# 8. Gender-wise Analysis
# ─────────────────────────────────────────────

def gender_analysis(df, students_df):
    merged = df.merge(students_df[["roll_no","gender"]], on="roll_no", how="left")
    return (merged.groupby("gender")["is_present"]
                  .mean()
                  .mul(100)
                  .round(2)
                  .reset_index()
                  .rename(columns={"is_present":"avg_attendance_pct"}))


# ─────────────────────────────────────────────
# 9. Overall Stats
# ─────────────────────────────────────────────

def overall_stats(df, student_summary_df):
    total_students  = student_summary_df["roll_no"].nunique()
    avg_attendance  = student_summary_df["attendance_pct"].mean()
    below_75        = (student_summary_df["attendance_pct"] < 75).sum()
    above_90        = (student_summary_df["attendance_pct"] >= 90).sum()
    perfect_100     = (student_summary_df["attendance_pct"] == 100).sum()

    return {
        "Total Students":           total_students,
        "Total Records":            len(df),
        "Overall Avg Attendance %": round(avg_attendance, 2),
        "Students Below 75%":       int(below_75),
        "Students Above 90%":       int(above_90),
        "Students with 100%":       int(perfect_100),
        "Departments Covered":      df["department"].nunique(),
        "Subjects Covered":         df["subject"].nunique(),
    }
